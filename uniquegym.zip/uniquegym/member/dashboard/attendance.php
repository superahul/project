<?php
session_start();
//Checking User Logged or Not
if(empty($_SESSION['user'])){
 header('location:./../../index.php');
}
//Restrict User or Moderator to Access Admin.php page
if($_SESSION['user']['role']=='Customer'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Member'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Trainer'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Admin'){
 header('location:./../../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">

	<link rel="stylesheet" type="text/css" href="./../assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/responsive.css">

	<script type="text/javascript" src="./../assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="./../assets/js/popper.min.js"></script>
	<script type="text/javascript" src="./../assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
</head>
<body>
	<?php include 'addons/header.php'; ?>
	<?php include 'addons/sidebar.php'; ?>
	<?php include 'addons/connection.php'; 
	?>
	<div class="contentCenterBody">
		<h5 align="center">Attendance</h5>
		<form method="post">
			<label>Enter email or contact:</label>
			<input type="text" name="search">
			<input type="submit" name="ok">
		</form>
		<table>
			

		<?php
		if(isset($_POST["ok"])){
			$s=$_POST["search"];
			$qry="select * from user_master where email='$s' or contact='$s'";
			$res=mysqli_query($conn,$qry);
			if (mysqli_num_rows($res)>0) { ?> 
			<tr align="center">
				<th width="20%">First Name</th>
				<th width="20%">Last Name</th>
				<th width="20%">Email</th>
				<th width="20%">Contact</th>
				<th width="20%">Attendance</th>
			</tr>
		<?php		while ($row = mysqli_fetch_assoc($res)) {	?>
					<tr align="center">
						<?php if ($row["user_id"]!="") {
							$i=$row["user_id"];
						}?>
						<td><?php echo $row["f_name"]; ?></td>
						<td><?php echo $row["l_name"]; ?></td>
						<td><?php echo $row["email"]; ?></td>
						<td><?php echo $row["contact"]; ?></td>
						<td><a href="add.php?id=<?php echo $row['user_id']; ?>">Present</a></td>
					</tr>
					<?php } }
							else{
								echo "<br /><b>Invalid Email or Contact!</b>";
							} }?>
		</table>		
	</div>
	<?php include 'addons/footer.php'; ?>
</body>
</html>