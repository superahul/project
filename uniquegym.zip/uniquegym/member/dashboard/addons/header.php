
<div class="warning_Badge badge_pop">
	Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magnam praesentium itaque eius repudiandae distinctio quibusdam culpa, vel hic pariatur excepturi optio laboriosam fugiat perferendis minus rerum maiores dolores facilis. Porro perferendis sunt voluptatem architecto corrupti eligendi tempora reprehenderit earum voluptatum.
	<div class="buttonYesNo">
		<button><i class="fa fa-check"></i></button>
		<button><i class="fa fa-times"></i></button>
	</div>
</div>
<div class="success_Badge badge_pop">
	Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magnam praesentium itaque eius repudiandae distinctio quibusdam culpa, vel hic pariatur excepturi optio laboriosam fugiat perferendis minus rerum maiores dolores facilis. Porro perferendis sunt voluptatem architecto corrupti eligendi tempora reprehenderit earum voluptatum.
	<div class="buttonYesNo">
		<button><i class="fa fa-check"></i></button>
		<button><i class="fa fa-times"></i></button>
	</div>
</div>
<div class="dange_badge badge_pop">
	Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magnam praesentium itaque eius repudiandae distinctio quibusdam culpa, vel hic pariatur excepturi optio laboriosam fugiat perferendis minus rerum maiores dolores facilis. Porro perferendis sunt voluptatem architecto corrupti eligendi tempora reprehenderit earum voluptatum.
	<div class="buttonYesNo">
		<button><i class="fa fa-check"></i></button>
		<button><i class="fa fa-times"></i></button>
	</div>
</div>


<div class="overlay"></div>




<div class="header">
	<div class="container-fluid p0">
		<div class="logo_place text-center">
			<img src="./../../img/logo.png" alt="a">
		</div>
		<div class="otherPartHeader">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6">
					</div>
					<div class="col-md-6 text-right">
						<ul class="nolistinline">
							<li>
								<span><i class="fa fa-user"></i> <?php echo $_SESSION['user']['username'];?> <i class="fa fa-angle-down"></i></span> 
								<ul class="submenu">
									<li><a href="profile.php">My Profile</a></li>
									<li><a href="changepassword.php">Change Password</a></li>
								</ul>
							</li>
							<li><a href="./../../logout.php"><i class="fa fa-sign-out"></i> Sign out</a></li>
						</ul>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>