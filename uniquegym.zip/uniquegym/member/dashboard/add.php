<?php include 'addons/connection.php';
	$i=$_GET['id'];
	$d=date("Y-m-d");
	if($d!="" && $i!=""){
		$query="INSERT INTO `attendance`(`date`, `attendance`, `user_master_user_id`) VALUES ('$d',1,'$i')";
		mysqli_query($conn,$query);
    	header("location:attendance.php");	}
    else{
    		echo "string";
    }
	?>
?>