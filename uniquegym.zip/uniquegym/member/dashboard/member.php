<?php
session_start();
//Checking User Logged or Not
if(empty($_SESSION['user'])){
 header('location:./../../index.php');
}
//Restrict User or Moderator to Access Admin.php page
if($_SESSION['user']['role']=='Customer'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Member'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Trainer'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Admin'){
 header('location:./../../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">

	<link rel="stylesheet" type="text/css" href="./../assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/responsive.css">

	<script type="text/javascript" src="./../assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="./../assets/js/popper.min.js"></script>
	<script type="text/javascript" src="./../assets/js/bootstrap.min.js"></script>

	
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
</head>
<body>
	<?php include 'addons/header.php'; ?>
	<?php include 'addons/sidebar.php'; ?>
	<?php include 'addons/connection.php'; 
	?>
	<div class="contentCenterBody">
		<h5 align="center">Customer</h5>
		<table>
			<tr align="center">
				<th width="13%">First Name</th>
				<th width="13%">Last Name</th>
				<th width="13%">Email</th>
				<th width="13%">Date of Birth</th>
				<th width="13%">Address</th>
				<th width="13%">Contact</th>
				<th width="13%">Photo</th>
				<th width="13%">Document</th>
			</tr>
		<?php
		$qry="SELECT u.f_name, u.l_name, u.email, u.dob, u.address, u.contact, u.photo, u.document FROM `user_type` AS t INNER JOIN `user_master` AS u ON t.type_id=u.user_type_type_id WHERE name='Member'";
		$res=mysqli_query($conn,$qry);
		if (mysqli_num_rows($res)>0) {  
				while ($row = mysqli_fetch_assoc($res)) {	?>
				
					<tr align="center">
						<td><?php echo $row["f_name"]; ?></td>
						<td><?php echo $row["l_name"]; ?></td>
						<td><?php echo $row["email"]; ?></td> 
						<td><?php echo $row["dob"]; ?></td>
						<td><?php echo $row["address"]; ?></td>
						<td><?php echo $row["contact"]; ?></td>
						<td><img src="<?php echo $row["photo"]; ?>" height="60" width="60" alternate="Pending"></td>
						<td><img src="<?php echo $row["document"]; ?>" height="60" width="60" alternate="Pending"></td>
					</tr><?php } } ?>
				</table>
	</div>
	<?php include 'addons/footer.php'; ?>
</body>
</html>