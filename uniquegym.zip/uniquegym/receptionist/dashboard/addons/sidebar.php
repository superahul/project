<div class="sideMenu">
	<div class="userDisplayCard">
		<p class="">Receptionist</p>
	</div>
	<div class="SideNavMenu">
		<ul>
			<li class="menu1 hasSideMenu">
				<a href="member.php"><i class="fa fa-home"></i> Member </a>
			<!--	<ul class="nav_sideMenu">
					<li class="menu3"><a href="customer.php"> Member </a></li>
					<li class="menu4"><a href="employee.php"> Employee </a></li>
				</ul>-->
			</li>
			<li class="hasSideMenu">
				<a href="employee.php"><i class="fa fa-home"></i> Employee </a>
			</li>
			<li class="hasSideMenu">
				<a href="activity.php"><i class="fa fa-home"></i> Activity </a>
				<ul class="nav_sideMenu">
				</ul>
			</li>
			<li class="hasSideMenu">
				<a href="attendance.php"><i class="fa fa-home"></i> Attendance </a>
			<!--	<ul class="nav_sideMenu">
					<li class="menu20"><a href="product_category.php"> Product Category </a></li>
					<li class="menu21"><a href="product.php">Product </a></li>
				</ul>-->
		<!--	</li>
			<li class="hasSideMenu">
				<a href="offer.php"><i class="fa fa-home"></i> Offer <i class="fa fa-angle-right right_drop"></i></a>
				<ul class="nav_sideMenu">
				</ul>
			</li>
			<li class="hasSideMenu">
				<a href="#"><i class="fa fa-home"></i> Customer Support <i class="fa fa-angle-right right_drop"></i></a>
				<ul class="nav_sideMenu">
					<li class="hasSideMenu">
					<a href="#"> Feedback <i class="fa fa-angle-right right_drop"></i></a>
						<ul class="nav_sideMenu">
							<li class="menu21"><a href="feedback_customer.php"> Customer Feedback </a></li>
							<li class="menu22"><a href="feedback_product.php"> Product Feedback </a></li>
						</ul>
					<li class="menu22"><a href="complain.php"> Complain </a></li>
					<li class="menu23"><a href="faqs.php"> FAQs </a></li>
				</ul>
			</li>
			<li class="hasSideMenu">
				<a href="#"><i class="fa fa-home"></i> Reports <i class="fa fa-angle-right right_drop"></i></a>
				<ul class="nav_sideMenu">
					<li class="menu27"><a href="#"> Single Line Incentive</a></li>
					<li class="menu28"><a href="#"> Ambassador Incentive</a></li>
					<li class="menu29"><a href="#"> Level Incentive</a></li>
					<li class="menu30"><a href="#"> Direct Referral Incentive</a></li>
					<li class="menu31"><a href="#"> Weekly Payout Summary</a></li>
					<li class="menu32"><a href="#"> Payout Summary</a></li>
				</ul>
			</li>-->

		</ul>
	</div>
</div>