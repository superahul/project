<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Unique Gym - Fitness HTML Template</title>
	<meta charset="UTF-8">
	<meta name="description" content="Unique Gym Fitness HTML Template">
	<meta name="keywords" content="fitness, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<!-- Favicon -->
	<link href="img/favicon.png" rel="shortcut icon"/>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&display=swap" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="css/flaticon.css"/>
	<link rel="stylesheet" href="css/slicknav.min.css"/>

	<!-- Main Stylesheets -->
	<link rel="stylesheet" href="css/style.css"/>


	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

	<!-- Header section -->
	<header class="header-section">
		<a href="index.php" class="site-logo">
			<img src="img/logo.png" alt="">
		</a>
		<ul class="main-menu">
			<li><a href="index.php">Home</a></li>
			<li><a href="packages.php">Packages</a></li>
			<li><a class="active" href="products.php">Products</a></li>
			<li><a href="contact.php">Contact us</a></li>
			<li><a href="login.php">Login</a></li>
			<li class="header-right">
				<div class="hr-box">
					<a href=""><img src="img/icons/cart.png" alt=""></a>
				</div>
			</li>
		</ul>
	</header>
	<div class="clearfix"></div>
	<!-- Header section end -->

	<!-- Page top section -->
	<section class="page-top-section set-bg" data-setbg="img/header-bg/4.jpg">
		<div class="container">
			<h2>Products </h2>
		</div>
	</section>
	<!-- space -->
	<ul>
		<li> </li>
		<li </li>
	</ul>
	<!-- Page top section end -->
	<?php
	include 'connection.php';
	$qry="select * from product";
	$res=mysqli_query($conn,$qry);
	/*if (mysqli_num_rows($res)>0) {
		echo "<table>";
		//echo "<thead>";
		echo "<tr>";
		echo "<th>ID</th>";
		echo "<th>name</th>";
		echo "<th>des</th>";
		echo "<th>weight</th>";
		echo "<th>price</th>";
		echo "<th>stock</th>";
		echo "<th>photo</th>";
		echo "</tr>";
		//echo "</thead>";
		//echo "<tbody>";
		while ($row = mysqli_fetch_assoc($res)) {
			echo "<tr>";
			echo "<td>".$row["product_id"]."</td>";
			echo "<td>".$row["name"]."</td>";
			echo "<td>".$row["description"]."</td>";
			echo "<td>".$row["weight"]."</td>";
			echo "<td>".$row["price"]."</td>";
			echo "<td>".$row["stock"]."</td>";
			echo "<td>".$row["photo"]."</td>";
			echo "</tr>";
		}
		//echo "</tbody>";
		echo "</table>";
	}*/
?>
	
	<div class="About Products">	
	<?php 
		if (mysqli_num_rows($res)>0) 
	{
		while ($row = mysqli_fetch_assoc($res)) 
	{ ?>
		<a href = "product_details.php"> <img src="<?php echo $row["photo"]; ?> " alt = "photo of product" width = "100" height ="" />
		<p> <?php echo $row["name"]; ?> </p>
		<p> Rs.<?php echo $row["price"]; ?> </p> </a> 
		<p> <?php echo $row["weight"]; ?>Gram </p>
		Qty: <input type="number" name="qty" min="1" max="10">
		<input type="submit" value="Add to cart">
		<hr>
	<?php }
	} ?>
	

	
	<!-- Footer section -->
	<footer class="footer-section set-bg" data-setbg="img/footer-bg.jpg">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-sm-6">
					<div class="footer-widget">
						<h4>Location</h4>
						<div class="fw-info-box">
							<img src="img/icons/1.png" alt="">
							<div class="fw-info-text">
								<p> Ghodasar Cross Road, Near Cadila Bridge, Ahmedabad-380050</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="footer-widget">
						<h4>Contact</h4>
						<div class="fw-info-box">
							<img src="img/icons/2.png" alt="">
							<div class="fw-info-text">
								<p>+91 9727974099</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="footer-widget">
						<h4>E-mail</h4>
						<div class="fw-info-box">
							<img src="img/icons/3.png" alt="">
							<div class="fw-info-text">
								<p>unique@gmail.com</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6 order-2 order-md-1">
					<div class="copyright"><p>
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved.</p></div>
				</div>
				<div class="col-md-6 order-1 order-md-2">
					<ul class="footer-menu">
						<li><a href="index.php">Home</a></li>
						<li><a href="packages.php">Packages</a></li>
						<li><a href="contact.php">Contact us</a></li>
						<li><a href="about.php">About us</a></li>
					</ul>
				</div>
			</div>
		</div>
	</footer>
	<!-- Footer section end -->
															
	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.slicknav.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/circle-progress.min.js"></script>
	<script src="js/main.js"></script>

	</body>
</html>