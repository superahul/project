	<button class="success">Success</button>
	<button class="error">Error</button>
	<button class="warning">Warning</button>
	<button class="info">Info</button>








<script type="text/javascript">
	$('.loginBtn').on('click',function(){
		
	});
</script>
	<script type="text/javascript">
		$('.success').on('click',function(){
			successAlert('Profile Update Successfully');
		});
		$('.error').on('click',function(){
			errorAlert('500: Internal Server Error');
		});
		$('.warning').on('click',function(){
			warningAlert('No Internet Connection');
		});
		$('.info').on('click',function(){
			infoAlert('User pending Info action');
		});
	</script>
