<!DOCTYPE html>
<html lang="zxx">
<title>
</title>
<body>
	
	<div class="">
	<?php
	include 'connection.php';
	$qry="select * from product";
	$res=mysqli_query($conn,$qry);
	/*if (mysqli_num_rows($res)>0) {
		echo "<table>";
		//echo "<thead>";
		echo "<tr>";
		echo "<th>ID</th>";
		echo "<th>name</th>";
		echo "<th>des</th>";
		echo "<th>weight</th>";
		echo "<th>price</th>";
		echo "<th>stock</th>";
		echo "<th>photo</th>";
		echo "</tr>";
		//echo "</thead>";
		//echo "<tbody>";
		while ($row = mysqli_fetch_assoc($res)) {
			echo "<tr>";
			echo "<td>".$row["product_id"]."</td>";
			echo "<td>".$row["name"]."</td>";
			echo "<td>".$row["description"]."</td>";
			echo "<td>".$row["weight"]."</td>";
			echo "<td>".$row["price"]."</td>";
			echo "<td>".$row["stock"]."</td>";
			echo "<td>".$row["photo"]."</td>";
			echo "</tr>";
		}
		//echo "</tbody>";
		echo "</table>";
	}*/
	?>
	<?php 
		if (mysqli_num_rows($res)>0) 
	{
		while ($row = mysqli_fetch_assoc($res)) 
	{ ?>
	<p>
		<a href=""> <img src="<?php echo $row["photo"]; ?>" alt="photo of product" width="210" height="250" />
		<h1> <?php echo $row["name"]; ?> </h1>  
		
		Qty <input type="number" name="qty" min="1" max="10">
			<button id="cart">Add To Cart</button> <?php }
	} ?>	
	</p>
	
	<p> <b>
			Size: 1 Kg / 2.2 lb
			This is a Vegetarian product.

    Muscleblaze super gainer is a high-calorie formula for bodybuilders in rich chocolate flavour				<br>
    2 Servings of muscleblaze super gainer xxl chocolate provide 1121 calories, 45g protein and 224g carbs			<br>
    Protein and complex carbs in the ratio of 1:5 in muscleblaze super gainer 6. 6 Lb 	<br>
	chocolate build energy and strength for brute training sessions <br>
    27 Vitamins and minerals fulfil the dietary gaps and keep you energetic enough to carry out difficult workouts	<br>
    No added sugar in muscleblaze super gainer 6.6 Lb chocolate ensures that the calories come from complex carbs and high-quality proteins
			<br>	<br>
	This product is limited to 2 units per customer This item is Returnable.
	</p>
	</div>
</body>
</html>