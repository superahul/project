<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Unique Gym</title>
	<meta charset="UTF-8">
	<meta name="description" content="Unique Gym Fitness HTML Template">
	<meta name="keywords" content="fitness, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<!-- Favicon -->
	<link href="img/favicon.png" rel="shortcut icon"/>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&display=swap" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="css/flaticon.css"/>
	<link rel="stylesheet" href="css/slicknav.min.css"/>

	<!-- Main Stylesheets -->
	<link rel="stylesheet" href="css/style.css"/>


	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

	<!-- Header section -->
	<header class="header-section">
		<a href="index.php" class="site-logo">
			<img src="img/logo.png" alt=""></a>
		<ul class="main-menu">
			<li><a href="index.php">Home</a></li>
			<li><a href="packages.php">Packages</a></li>
			<li><a href="products.php">Products</a></li>
			<li><a href="contact.php">Contact us</a></li>
			<li><a class="active" href="login.php">Login</a></li>
			<li class="header-right">
				<div class="hr-box">
					<a href=""><img src="img/icons/cart.png" alt=""></a>
				</div>
			</li>
		</ul>
	</header>
	<div class="clearfix"></div>
	<!-- Header section end -->

	<?php
		session_start();
		include 'connection.php';
		if(isset($_POST['login'])){
  			$username=mysqli_real_escape_string($conn,$_POST['username']);
  			$password=mysqli_real_escape_string($conn,$_POST['password']);
  			if(empty($username)&&empty($password)){
  				$error= 'Fileds are Mandatory'; 
  			}else{
 				//Checking Login Detail
 				$result=mysqli_query($conn,"SELECT u.user_id, u.f_name, u.l_name, u.email, u.password, t.name FROM `user_type` AS t INNER JOIN `user_master` AS u ON t.type_id=u.user_type_type_id WHERE u.email='$username' AND u.password='$password'");
 				$row=mysqli_fetch_assoc($result);
 				$count=mysqli_num_rows($result);
 				if($count==1){
      				$_SESSION['user']=array(
   					'username'=>$row['f_name'] ." ". $row['l_name'],
   					'role'=>$row['name'],
   					'id'=>$row['user_id'] );
  					$role=$_SESSION['user']['role'];
   					//Redirecting User Based on Role
    				switch($role){
  						case 'Customer':
  						header('location:index.php');
  						break;
  						case 'Member':
  						header('location:member/dashboard/index.php');
  						break;
  						case 'Admin':
  						header('location:admin/dashboard/index.php');
  						break;
  						case 'Receptionist':
  						header('location:receptionist/dashboard/index.php');
  						break;
  						case 'Trainer':
  						header('location:trainer/dashboard/index.php');
  						break; 
  					}
 				}else{
 					echo '<div class="row"><div class="col-md-4"></div><div class="col-md-4"><div class="alert alert-danger alert-dismissible">
    					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    					 Incorrect email or password!
  					</div></div><div class="col-md-4"></div></div>';
 					 
 				}
			}
		}
	?>
	<div class="row">
	<div class="col-md-4"></div><div class="col-md-4">
	<form class="form-horizontal" method="POST" action="">
		<div class="form-group">
          <label class="control-label">E-mail:</label>
          <input type="email" class="form-control" id="email" placeholder="Enter E-mail" name="username" required>
          <div class="invalid-feedback">Please fill out this field.</div>
        </div>
        <div class="form-group">
          <label for="password">Password:</label>
          <input type="password" class="form-control" id="password" placeholder="Enter Password" name="password" required>
          <div class="invalid-feedback">Please fill out this field.</div>
        </div>
         <div class="form-group">
          <input type="submit" name="login" value="Login">
        </div>
		<a href="">Forgot Password?</a><br />
		<a href="registeration.php">Create Account.</a>
	</form>
	<?php if(isset($error)){ echo $error; }?>
	</div>
	<div class="col-md-4"></div>
	</div>

	<!-- Footer section 
	<footer class="footer-section set-bg" data-setbg="img/footer-bg.jpg">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-sm-6">
					<div class="footer-widget">
						<h4>Location</h4>
						<div class="fw-info-box">
							<img src="img/icons/1.png" alt="">
							<div class="fw-info-text">
								<p> Ghodasar Cross Road, Near Cadila Bridge, Ahmedabad-380050</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="footer-widget">
						<h4>Contact</h4>
						<div class="fw-info-box">
							<img src="img/icons/2.png" alt="">
							<div class="fw-info-text">
								<p>+91 9727974099</p>
								<p></p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="footer-widget">
						<h4>E-mail</h4>
						<div class="fw-info-box">
							<img src="img/icons/3.png" alt="">
							<div class="fw-info-text">
								<p>unique@gmail.com</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6 order-2 order-md-1">
					<div class="copyright"><p>
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved.</p></div>
				</div>
				<div class="col-md-6 order-1 order-md-2">
					<ul class="footer-menu">
						<li><a href="index.php">Home</a></li>
						<li><a href="packages.php">Package</a></li>
						<li><a href="products.php">Product</a></li>
						<li><a href="about.php">About us</a></li>
						<li><a href="contact.php">Contact us</a></li>
					</ul>
				</div>
			</div>
		</div>
	</footer>
	 Footer section end -->
									
	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.slicknav.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/circle-progress.min.js"></script>
	<script src="js/main.js"></script>
	<script type="text/javascript">
		$('.success').on('click',function(){
			successAlert('Profile Update Successfully');
		});
		$('.error').on('click',function(){
			errorAlert('500: Internal Server Error');
		});
		$('.warning').on('click',function(){
			warningAlert('No Internet Connection');
		});
		$('.info').on('click',function(){
			infoAlert('User pending Info action');
		});
	</script>

	</body>
</html>

<!--
<table>
   <tr>
     <td>UserName:</td>
  <td><input type="text" name="username"/></td>
   </tr>
   <tr>
     <td>Password:</td>
  <td><input type="password" name="password"/></td>
   </tr>
   <tr>
     <td></td>
  <td><input type="submit" name="login" value="Login"/></td>
   </tr>
</table>
-->