<?php 
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">

	<link rel="stylesheet" type="text/css" href="./../assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/responsive.css">

	<script type="text/javascript" src="./../assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="./../assets/js/popper.min.js"></script>
	<script type="text/javascript" src="./../assets/js/bootstrap.min.js"></script>

	
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
</head>
<body>
	<?php include 'addons/header.php'; ?>
	<?php include 'addons/sidebar.php'; ?>
	<?php include 'addons/db.php'; ?>
	<div class="contentCenterBody">
		<form method="POST" action="" enctype="multipart/form-data">
			<?php  ?>
			<table>
				<tr>
					<td>Name:</td><td><input type="text" name="name" value=""></td>
				</tr>
				<tr>
					<td>Designation:</td><td><input type="text" name="desi"></td>
				</tr>
				<tr>
					<td>Description:</td><td><input type="text" name="desc"></td>
				</tr>
				<tr>
					<td>email:</td><td><input type="text" name="email"></td>
				</tr>
				<tr>
					<td>Password:</td><td><input type="password" name="password"></td>
				</tr>
				<tr>
          			<td>Photo:</td><td><input type="file" name="photo"></td>
          			<td border:0px>
          			<?php
          			//function upDoc(){
            			if(isset($_POST['submit'])){
              				$file_name=$_FILES['photo']['name'];
              				$file_temp_loc=$_FILES['photo']['tmp_name'];
              				$file_store="./../../upload/".$file_name;
              				if(move_uploaded_file($file_temp_loc, $file_store)){
                				echo "uploaded";
              				}
            			}
            		//} 
          			?>
          			</td>
        		</tr>
				<tr>
					<td colspan=2 align="center"><input type="submit" name="submit" value="SUBMIT"></td>
				</tr>
			</table>
		</form>
		<?php
		if(isset($_POST['submit'])){
			//$t=$_POST["type"];
			$n=$_POST["name"];
			$d1=$_POST["desi"];
			$d2=$_POST["desc"];
			$e=$_POST["email"];
			$p=$_POST["password"];
			$i="./../../upload/".$_FILES['photo']['name'];
			if($n!="" && $d1!="" && $d2!="" && $p!="" && $e!="" && $i!=""){
				$query="INSERT INTO `team`(`Name`, `Designation`, `Description`, `password`, `email`, `img`) VALUES ('$n','$d1','$d2','$p','$e','$i')";
				if(mysqli_query($conn,$query)){
    				echo "Records inserted successfully.<br />";
    				echo "<a href='Team.php'>back</a>"; }
				else{
    				echo "ERROR: Could not able to execute $query. " . mysqli_error($conn); } }
    			else{
    				echo "Fields are mandatory";
    			} }
    	
    			
	
		?>
	</div>
	<?php include 'addons/footer.php'; ?>
</body>
</html>