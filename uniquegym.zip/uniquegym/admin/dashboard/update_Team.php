<?php 
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">

	<link rel="stylesheet" type="text/css" href="./../assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/responsive.css">

	<script type="text/javascript" src="./../assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="./../assets/js/popper.min.js"></script>
	<script type="text/javascript" src="./../assets/js/bootstrap.min.js"></script>

	
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
</head>
<body>
	<?php include 'addons/header.php'; ?>
	<?php include 'addons/sidebar.php'; ?>
	<?php include 'addons/db.php'; ?>
	<?php $edit=$_GET['eid']; ?>
	<div class="contentCenterBody">
		<form method="POST" action="" enctype="multipart/form-data">
		<?php	
			$qry="SELECT * FROM `team` WHERE `Id`='$edit'";
			$res=mysqli_query($conn,$qry);
			if (mysqli_num_rows($res)>0) {  
				while ($row = mysqli_fetch_assoc($res)) {	?>
			<table>
				<tr>
					<td>Name:</td><td><input type="text" name="name" value="<?php echo $row['Name']; ?>"></td>
				</tr>
				<tr>
					<td>Designation:</td><td><input type="text" name="desi" value="<?php echo $row['Designation']; ?>"></td>
				</tr>
				<tr>
					<td>Description:</td><td><input type="text" name="desc" value="<?php echo $row['Description']; ?>"></td>
				</tr>
				<tr>
					<td>email:</td><td><input type="text" name="email" value="<?php echo $row['email']; ?>"></td>
				</tr>
				<tr>
					<td>Password:</td><td><input type="password" name="password" value="<?php echo $row['password']; ?>"></td>
				</tr>
				<tr>
          			<td>Photo:</td><td><input type="file" name="photo"></td>
          			<td border:0px>
          			<?php
          			//function upDoc(){
            			if(isset($_POST['submit'])){
              				$file_name=$_FILES['photo']['name'];
              				$file_temp_loc=$_FILES['photo']['tmp_name'];
              				$file_store="./../../upload/".$file_name;
              				if(move_uploaded_file($file_temp_loc, $file_store)){
                				echo "uploaded";
              				}
            			}
            		//} 
          			?>
          			</td>
        		</tr>
        		<?php $file=$row['img']; ?>
				<tr>
					<td colspan=2 align="center"><input type="submit" name="submit" value="SUBMIT"></td>
				</tr>
			</table>
			<?php } }?>
		</form>
		<?php
		if(isset($_POST['submit'])){
			//$t=$_POST["type"];
			$n=$_POST["name"];
			$d1=$_POST["desi"];
			$d2=$_POST["desc"];
			$e=$_POST["email"];
			$p=$_POST["password"];
			$i="./../../upload/".$_FILES['photo']['name'];
			if($n!="" && $d1!="" && $d2!="" && $p!="" && $e!="" && $i!=""){
				$query="UPDATE `team` SET `Name`='$n',`Designation`='$d1',`Description`='$d2',`password`='$p',`email`='$e',`img`='$i' WHERE `Id`='$edit'";
				if(mysqli_query($conn,$query)){
    				echo "Records updated successfully.<br />";
    				unlink($file);
    				echo "<a href='Team.php'>back</a>"; }
				else{
    				echo "ERROR: Could not able to execute $query. " . mysqli_error($conn); } }
    			else{
    				echo "Fields are mandatory";
    			} }
    	
    			
	
		?>
	</div>
	<?php include 'addons/footer.php'; ?>
</body>
</html>