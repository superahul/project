<?php include 'addons/db.php'; 
	$del=$_GET['did'];
	$img=$_GET['img'];
	if($del!=""){
		$query="DELETE FROM `team` WHERE Id='$del'";
		mysqli_query($conn,$query); 
	}
	if ($img!="") {
		unlink($img);
	}
    	header("location:Team.php");		
	?>