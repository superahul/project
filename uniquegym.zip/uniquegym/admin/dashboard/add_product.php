<?php
session_start();
//Checking User Logged or Not
if(empty($_SESSION['user'])){
 header('location:index.php');
}
//Restrict User or Moderator to Access Admin.php page
if($_SESSION['user']['role']=='Customer'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Member'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Trainer'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Receptionist'){
 header('location:./../../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">

	<link rel="stylesheet" type="text/css" href="./../assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/responsive.css">

	<script type="text/javascript" src="./../assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="./../assets/js/popper.min.js"></script>
	<script type="text/javascript" src="./../assets/js/bootstrap.min.js"></script>

	
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
</head>
<body>
	<?php include 'addons/header.php'; ?>
	<?php include 'addons/sidebar.php'; ?>
	<?php include 'addons/connection.php'; ?>
	<div class="contentCenterBody">
		<form method="post" enctype="multipart/form-data">
			<table>
				<tr>
          			<td>Employee type:</td>
          			<td>
            			<select name="type">
              			<?php $qry="SELECT * FROM `product_type`";
              				$res=mysqli_query($conn,$qry);
              				if (mysqli_num_rows($res)>0) {  
                				while ($row = mysqli_fetch_assoc($res)) { ?>
              					<option value="<?php echo $row['type_id']; ?>"><?php echo $row['category'];?></option>
              				<?php } }?>
            			</select>
          			</td>
        		</tr>
				<tr>
					<td>Name:</td><td><input type="text" name="name"></td>
				</tr>
				<tr>
					<td>Description:</td><td><input type="text" name="des"></td>
				</tr>
				<tr>
					<td>Weight(in grams):</td><td><input type="number" name="weight"></td>
				</tr>
				<tr>
					<td>price:</td><td><input type="number" name="price"></td>
				</tr>
				<tr>
					<td>Stock:</td><td><input type="number" name="stock"></td>
				</tr>
				<tr>
          			<td>Photo:</td><td><input type="file" name="photo"></td>
          			<td border:0px>
          			<?php
          			//function upDoc(){
            		if(isset($_POST['submit'])){
              			$file_name=$_FILES['photo']['name'];
              			$file_temp_loc=$_FILES['photo']['tmp_name'];
              			$file_store="./../../upload/".$file_name;
              			if(move_uploaded_file($file_temp_loc, $file_store)){
                			echo "uploaded";
              			}
            		} 
          			?>
          			</td>
        		</tr>
				<tr>
					<td colspan=2 align="center"><input type="submit" name="submit" value="SUBMIT"></td>
				</tr>
			</table>
		</form>
		<?php
		if(isset($_POST['submit'])){
			$t=$_POST["type"];
			$n=$_POST["name"];
			$d=$_POST["des"];
			$w=$_POST["weight"];
			$p=$_POST["price"];
			$s=$_POST["stock"];
			$pf="./../../upload/".$_FILES['photo']['name'];
			if($n!="" && $d!="" && $w!="" && $p!="" && $s!="" && $pf!="" && $t!=""){
			$query="INSERT INTO `product`(`name`, `description`, `weight`, `price`, `stock`, `photo`, `product_type_type_id`, `company_company_id`) VALUES ('$n','$d','$w','$p','$s','$pf','$t',1)";
			if(mysqli_query($conn,$query)){
    			echo "Records inserted successfully.<br />";
    			echo "<a href='product.php'>back</a>"; }
			else{
    			echo "ERROR: Could not able to execute $query. " . mysqli_error($conn); } } }
    	
    			
	
		?>
	</div>
	<?php include 'addons/footer.php'; ?>
</body>
</html>