<?php include 'addons/connection.php'; 
	$del=$_GET['did'];
	if($del!=""){
		$query="DELETE FROM `product_type` WHERE type_id='$del'";
		mysqli_query($conn,$query); }
    	header("location:product_category.php")		
	?>