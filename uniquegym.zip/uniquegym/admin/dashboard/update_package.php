<?php
session_start();
//Checking User Logged or Not
if(empty($_SESSION['user'])){
 header('location:index.php');
}
//Restrict User or Moderator to Access Admin.php page
if($_SESSION['user']['role']=='Customer'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Member'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Trainer'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Receptionist'){
 header('location:./../../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">

	<link rel="stylesheet" type="text/css" href="./../assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/responsive.css">

	<script type="text/javascript" src="./../assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="./../assets/js/popper.min.js"></script>
	<script type="text/javascript" src="./../assets/js/bootstrap.min.js"></script>

	
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
</head>
<body>
	<?php include 'addons/header.php'; ?>
	<?php include 'addons/sidebar.php'; ?>
	<?php include 'addons/connection.php'; 
	?>
	<div class="contentCenterBody">
		<form method="post">
			<table>
				<tr>
					<td>Name:</td><td><input type="text" name="name"></td>
				</tr>
				<tr>
					<td>Description:</td><td><input type="text" name="des"></td>
				</tr>
				<tr>
					<td>price:</td><td><input type="number" name="price"></td>
				</tr>
				<tr>
					<td>Start Date:</td><td><input type="date" name="sdate"></td>
				</tr>
				<tr>
					<td>End Date:</td><td><input type="date" name="edate"></td>
				</tr>
				<tr>
					<td colspan=2 align="center"><input type="submit" name="submit" value="SUBMIT"></td>
				</tr>
			</table>
		</form>
		<?php
		if(isset($_POST['submit'])){
			$i=$_GET['eid'];
			$n=$_POST["name"];
			$d=$_POST["des"];
			$p=$_POST["price"];
			$s=$_POST["sdate"];
			$e=$_POST["edate"];
			if($n!="" && $d!="" && $p!="" && $s!="" && $e!="" && $i!=""){
			$query="UPDATE `package` SET `name`='$n',`description`='$d',`price`='$p',`start_date`='$s',`end_date`='$e' WHERE `package_id`='$i'";
			if(mysqli_query($conn,$query)){
    			echo "Records inserted successfully.";
    			echo "<a href='package.php'>back</a>"; }
			else{
    			echo "ERROR: Could not able to execute $query. " . mysqli_error($conn); } } }
    	?>
	</div>
	<?php include 'addons/footer.php'; ?>
</body>
</html>