<?php include 'addons/connection.php'; 
	$del=$_GET['id'];
	if($del!=""){
		$query="UPDATE `user_master` SET `user_type_type_id`=2 WHERE user_id='$del'";
		mysqli_query($conn,$query); }
    	header("location:add_member.php");		
	?>