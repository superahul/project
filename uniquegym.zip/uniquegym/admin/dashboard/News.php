<?php 
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">

	<link rel="stylesheet" type="text/css" href="./../assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/responsive.css">

	<script type="text/javascript" src="./../assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="./../assets/js/popper.min.js"></script>
	<script type="text/javascript" src="./../assets/js/bootstrap.min.js"></script>

	
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
	
</head>
<body>
	<?php include 'addons/header.php'; ?>
	<?php include 'addons/sidebar.php'; ?>
	<?php include 'addons/db.php'; 
	?>
	<div class="contentCenterBody">
		<h5 align="center">News Details</h5>
		<a href="add_News.php">Add News</a>
		<table>
			<tr align="center">
				<th width="15%">Sr No.</th>
				<th width="15%">Image</th>
				<th width="15%">Paragraph</th>
				<th width="15%">Heading</th>
				<th colspan="2">Action</th>
				<th></th>
			</tr>
		<?php
		$qry="SELECT * FROM `news`";
		$res=mysqli_query($conn,$qry);
		$i=1;
		if (mysqli_num_rows($res)>0) {  
				while ($row = mysqli_fetch_assoc($res)) {	?>
				
					<tr align="center">
						<td><?php echo $i; $i=$i+1; ?></td>
						<td><img src="<?php echo $row['img']; ?>" height="60" width="60"></td>
						<td><?php echo $row["paragraph"]; ?></td>
						<td><?php echo $row["heading"]; ?></td>
						<!--<td><?php// echo $row["weight"]; ?></td>
						<td><?php// echo $row["price"]; ?></td>
						<td><?php// echo $row["stock"]; ?></td>
						<td><img src="<?php// echo "./../../".$row["photo"]; ?>" height="60" width="60"></td>-->
						<td><a href="update_News.php?eid=<?php echo $row['news_id'];?>">Edit</a></td>
						<td><a href="delete_News.php?did=<?php echo $row['news_id'];?>&&img=<?php echo $row['img'];?>">Delete</a></td>
					</tr><?php } } ?>
		</table>
	</div>
	<?php include 'addons/footer.php'; ?>
</body>
</html>