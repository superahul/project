<?php include 'addons/db.php'; 
	$del=$_GET['did'];
	$img=$_GET['img'];
	if($del!=""){
		$query="DELETE FROM `news` WHERE news_id='$del'";
		mysqli_query($conn,$query);
	}
	if ($img!="") {
		unlink($img);
	}
    	header("location:News.php");		
	?>