<?php 
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">

	<link rel="stylesheet" type="text/css" href="./../assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/responsive.css">

	<script type="text/javascript" src="./../assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="./../assets/js/popper.min.js"></script>
	<script type="text/javascript" src="./../assets/js/bootstrap.min.js"></script>

	
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
	
</head>
<body>
	<?php include 'addons/header.php'; ?>
	<?php include 'addons/sidebar.php'; ?>
	<?php include 'addons/db.php'; 
	?>
	<div class="contentCenterBody">
		<h5 align="center">Team Details</h5>
		<a href="add_Team.php">Add Team</a>
		<table>
			<tr align="center">
				<th width="15%">Sr No.</th>
				<th width="15%">Team Img</th>
				<th width="15%">Name</th>
				<th width="15%">Designation</th>
				<th width="15%">Discription</th>
				<th colspan="2">Action</th>
				<th></th>
			</tr>
		<?php
		$qry="SELECT * FROM `team`";
		$res=mysqli_query($conn,$qry);
		$i=1;
		if (mysqli_num_rows($res)>0) {  
				while ($row = mysqli_fetch_assoc($res)) {	?>
				
					<tr align="center">
						<td><?php echo $i; $i=$i+1; ?></td>
						<td><img src="<?php echo $row['img']; ?>" height="60" width="60"></td>
						<td><?php echo $row["Name"]; ?></td>
						<td><?php echo $row["Designation"]; ?></td>
						<td><?php echo $row["Description"]; ?></td>
						<!--<td><?php// echo $row["weight"]; ?></td>
						<td><?php// echo $row["price"]; ?></td>
						<td><?php// echo $row["stock"]; ?></td>
						<td><img src="<?php// echo "./../../".$row["photo"]; ?>" height="60" width="60"></td>-->
						<td><a href="update_Team.php?eid=<?php echo $row['Id'];?>">Edit</a></td>
						<td><a href="delete_Team.php?did=<?php echo $row['Id'];?>&&img=<?php echo $row['img'];?>">Delete</a></td>
					</tr><?php } } ?>
		</table>
	</div>
	<?php include 'addons/footer.php'; ?>
</body>
</html>