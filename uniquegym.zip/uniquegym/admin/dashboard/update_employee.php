<?php
session_start();
//Checking User Logged or Not
if(empty($_SESSION['user'])){
 header('location:index.php');
}
//Restrict User or Moderator to Access Admin.php page
if($_SESSION['user']['role']=='Customer'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Member'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Trainer'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Receptionist'){
 header('location:./../../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard</title>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">

  <link rel="stylesheet" type="text/css" href="./../assets/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="./../assets/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="./../assets/css/style.css">
  <link rel="stylesheet" type="text/css" href="./../assets/css/responsive.css">

  <script type="text/javascript" src="./../assets/js/jquery.min.js"></script>
  <script type="text/javascript" src="./../assets/js/popper.min.js"></script>
  <script type="text/javascript" src="./../assets/js/bootstrap.min.js"></script>

  
  <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
</head>
<body>
  <?php include 'addons/header.php'; ?>
  <?php include 'addons/sidebar.php'; ?>
  <?php include 'addons/connection.php'; 
  ?>
  <div class="contentCenterBody">
    <form method="post" enctype="multipart/form-data">
      <table>
        <tr>
          <td>First Name:</td><td><input type="text" name="fname"></td>
        </tr>
        <tr>
          <td>Last Name:</td><td><input type="text" name="lname"></td>
        </tr>
        <tr>
          <td>Date of Birth:</td><td><input type="date" name="dob"></td>
        </tr>
        <tr>
          <td>Address:</td><td><input type="text" name="address"></td>
        </tr>
        <tr>
          <td>Contact:</td><td><input type="number" name="contact"></td>
        </tr>
        <tr>
          <td>Email:</td><td><input type="text" name="email"></td>
        </tr>
        <tr>
          <td>password:</td><td><input type="password" name="password"></td>
        </tr>
        <tr>
          <td>Security Questions:</td><td><input type="text" name="sec_ques"></td>
        </tr>
        <tr>
          <td>Security Answer:</td><td><input type="text" name="sec_ans"></td>
        </tr>
        <tr>
          <td>
            photo:</td><td><input type="file" name="photo">
          </td>
          <td border:0px>
          <?php
          //function upPhoto(){
            if(isset($_POST['submit'])){
              $pfile_name=$_FILES['photo']['name'];
              $pfile_temp_loc=$_FILES['photo']['tmp_name'];
              $pfile_store="./../../upload/".$pfile_name;
              if(move_uploaded_file($pfile_temp_loc, $pfile_store)){
                echo "uploaded";
              }
            }
          ?>
          </td>
        </tr>
        <tr>
          <td>
            Document:</td><td><input type="file" name="doc">
          </td>
          <td border:0px>
          <?php
          //function upDoc(){
            if(isset($_POST['submit'])){
              $dfile_name=$_FILES['doc']['name'];
              $dfile_temp_loc=$_FILES['doc']['tmp_name'];
              $dfile_store="./../../upload/".$dfile_name;
              if(move_uploaded_file($dfile_temp_loc, $dfile_store)){
                echo "uploaded";
              }
            } 
          ?>
          </td>
        </tr>
        <tr>
          <td>
            Certificate:</td><td><input type="file" name="cer">
          </td>
          <td border:0px>
          <?php
          //function upCer(){
            if(isset($_POST['submit'])){
              $cfile_name=$_FILES['cer']['name'];
              $cfile_temp_loc=$_FILES['cer']['tmp_name'];
              $cfile_store="./../../upload/".$cfile_name;
              if(move_uploaded_file($cfile_temp_loc, $cfile_store)){
                echo "uploaded";
              }
            } 
          ?>
          </td>
        </tr>
        <tr>
          <td>Employee type:</td>
          <td>
            <select name="type">
              <?php $qry="SELECT * FROM `user_type` WHERE name!='Customer' AND name!='Member'";
              $res=mysqli_query($conn,$qry);
              if (mysqli_num_rows($res)>0) {  
                while ($row = mysqli_fetch_assoc($res)) { ?>
              ?>
              <option value="<?php echo $row['type_id']; ?>"><?php echo $row['name'];?></option>
              <?php } }?>
            </select>
          </td>
        </tr>
        <tr>
          <td colspan=2 align="center"><input type="submit" name="submit" value="ADD"></td>
        </tr>
      </table>
    </form>
    <?php
    if(isset($_POST['submit'])){
      $i=$_GET["eid"];
      $f=$_POST["fname"];
      $l=$_POST["lname"];
      $d=$_POST["dob"];
      $a=$_POST["address"];
      $c=$_POST["contact"];
      $e=$_POST["email"];
      $p=$_POST["password"];
      $sq=$_POST["sec_ques"];
      $sa=$_POST["sec_ans"];
      $pf=$_FILES['photo']['name'];
      $df=$_FILES['doc']['name'];
      $cf=$_FILES['cer']['name'];
      $t=$_POST['type'];
      if($i!="" && $f!="" && $l!="" && $d!="" && $a!="" && $c!="" && $e!="" && $p!="" && $sq!="" && $sa!="" && $pf!="" && $df!="" && $cf!="" && $t!=""){
      $query="UPDATE `user_master` SET `f_name`='$f',`l_name`='$l',`dob`='$d',`address`='$a',`contact`='$c',`email`='$e',`password`='$p',`sec_question`='$sq',`sec_answer`='$sa',`photo`='$pf',`document`='$df',`certificate`='$cf',`company_company_id`=1,`user_type_type_id`='$t' WHERE `user_id`='$i'";
      if(mysqli_query($conn,$query)){
          echo "Records inserted successfully.";
          echo "<a href='employee.php'>back</a>"; }
      else{
          echo "ERROR: Could not able to execute $query. " . mysqli_error($conn); } } }
      
          
  
    ?>
  </div>
  <?php include 'addons/footer.php'; ?>
</body>
</html>