<?php
	$conn = mysqli_connect('localhost','root','','testdb');
	if (!$conn) {
		die( "couldnot connect db" . mysqli_error($conn));
	}
	else
	{
		echo "";
	}
?> 