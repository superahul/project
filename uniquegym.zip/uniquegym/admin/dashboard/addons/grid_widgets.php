<div class="grid_widgets">
	<div class="col-md-12">
		<div class="row">
			<div class="col-md-3">
				<div class="widgetBox Wid1">
					<i class="fa fa-user-plus"></i>
					<h5 class="">AP47801</h5>
					<p>28-01-2019</p>
				</div>
			</div>
			<div class="col-md-3">
				<div class="widgetBox Wid2">
					<i class="fa fa-users"></i>
					<h5 class="">Rank</h5>
					<p>Bronze</p>
				</div>
			</div>
			<div class="col-md-3">
				<div class="widgetBox Wid3">
					<i class="fa fa-money"></i>
					<h5 class="">Total Earnings</h5>
					<p>78892.00</p>
				</div>
			</div>
			<div class="col-md-3">
				<div class="widgetBox Wid4">
					<i class="fa fa-inr"></i>
					<h5 class="">Wallet Balance</h5>
					<p>1223.15</p>
				</div>
			</div>
		</div>
	</div>
</div>