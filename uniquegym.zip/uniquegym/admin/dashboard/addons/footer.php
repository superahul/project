<script type="text/javascript">

	$(document).ready(function(){
		var contentBody = $('.contentCenterBody').height() + $('.grid_widgets').height();
		console.log(contentBody);
		$('.sideMenu').css({'min-height':contentBody+50+'px'});
		$('.treeViews').css({'min-height':contentBody+50+'px'});
	});
	

	$('.nolistinline li span').on('click',function(){
		$('.submenu').slideToggle();
	});


	$('.hasSideMenu a').on('click',function(){
		$(this).siblings('.nav_sideMenu').slideToggle();
		$(this).children('.right_drop').toggleClass('openedDrop');
	});



	$('.blockconn').on('click',function(){
		$(this).siblings('.childTree').slideToggle();
		$(this).parent().siblings('li').children('.childTree').slideUp();
	})
	


	$('.call_Success').on('click',function(){
		$('.overlay').fadeIn();
		$('.badge_pop').removeClass('activeBadge');
		$('.success_Badge').addClass('activeBadge');
	});
	$('.call_Danger').on('click',function(){
		$('.overlay').fadeIn();
		$('.badge_pop').removeClass('activeBadge');
		$('.dange_badge').addClass('activeBadge');
	});
	$('.call_Warning').on('click',function(){
		$('.overlay').fadeIn();
		$('.badge_pop').removeClass('activeBadge');
		$('.warning_Badge').addClass('activeBadge');
	});


	$('.buttonYesNo .fa-check').on('click',function(){
		alert("perform a action here...!");
		$('.badge_pop').removeClass('activeBadge');
		$('.overlay').fadeOut();
	});
	$('.buttonYesNo .fa-times').on('click',function(){
		$('.badge_pop').removeClass('activeBadge');
		$('.overlay').fadeOut();
	});

</script>