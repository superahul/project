<?php
session_start();
//Checking User Logged or Not
if(empty($_SESSION['user'])){
 header('location:index.php');
}
//Restrict User or Moderator to Access Admin.php page
if($_SESSION['user']['role']=='Customer'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Member'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Trainer'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Receptionist'){
 header('location:./../../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">

	<link rel="stylesheet" type="text/css" href="./../assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/responsive.css">

	<script type="text/javascript" src="./../assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="./../assets/js/popper.min.js"></script>
	<script type="text/javascript" src="./../assets/js/bootstrap.min.js"></script>

	
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
</head>
<body>
	<?php include 'addons/header.php'; ?>
	<?php include 'addons/sidebar.php'; ?>
	<?php include 'addons/connection.php'; 
	?>
	<div class="contentCenterBody">
		<h5 align="center">Product Categary</h5>
		<form method="post">
			<table>
				<tr>
					<td>Enter Category Name:</td><td><input type="text" name="category"></td>
				</tr>
				<tr>
					<td colspan=2 align="center"><input type="submit" name="submit" value="SUBMIT"></td>
				</tr>
			</table>
		</form>
		<br />
		<?php
		if(isset($_POST['submit'])){
			$c=$_POST["category"];
			if($c!=""){
			$query="INSERT INTO `product_type`(category) VALUES ('$c')";
			if(mysqli_query($conn,$query)){
    			echo "Records inserted successfully."; }
			else{
    			echo "ERROR: Could not able to execute $query. " . mysqli_error($conn); } } }
		?>
		<table>
			<tr align="center">
				<th width="20%"></th>
				<th width="20%">Name</th>
			</tr>
		<?php
		$qry="select * from product_type";
		$res=mysqli_query($conn,$qry);
		if (mysqli_num_rows($res)>0) {  
				while ($row = mysqli_fetch_assoc($res)) {	?>
				
					<tr align="center">
						<td><a href="delete_product_category.php?did=<?php echo $row['type_id'];?>">Delete</a></td>
						<td><?php echo $row["category"]; ?></td>
					</tr><?php } } ?>
		</table>
	</div>
	<?php include 'addons/footer.php'; ?>
</body>
</html>