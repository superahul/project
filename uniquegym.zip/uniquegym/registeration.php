<!DOCTYPE html>
<html lang="zxx">
<head>
  <title>Unique Gym - Fitness HTML Template</title>
  <meta charset="UTF-8">
  <meta name="description" content="Unique Gym Fitness HTML Template">
  <meta name="keywords" content="fitness, html">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <!-- Favicon -->
  <link href="img/favicon.png" rel="shortcut icon"/>

  <!-- Google font -->
  <link href="https://fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&display=swap" rel="stylesheet">

  <!-- Stylesheets -->
  <link rel="stylesheet" href="css/bootstrap.min.css"/>
  <link rel="stylesheet" href="css/font-awesome.min.css"/>
  <link rel="stylesheet" href="css/owl.carousel.min.css"/>
  <link rel="stylesheet" href="css/flaticon.css"/>
  <link rel="stylesheet" href="css/slicknav.min.css"/>

  <!-- Main Stylesheets -->
  <link rel="stylesheet" href="css/style.css"/>


  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

</head>
<body>
  <!-- Page Preloder -->
  <div id="preloder">
    <div class="loader"></div>
  </div>

  <!-- Header section -->
  <header class="header-section">
    <a href="index.php" class="site-logo">
      <img src="img/logo.png" alt="">
    </a>
    <ul class="main-menu">
      <li><a href="index.php">Home</a></li>
      <li><a href="packages.php">Packages</a></li>
      <li><a href="products.php">Products</a></li>
      <li><a href="contact.php">Contact us</a></li>
      <li><a href="login.php">Login</a></li>
      <li class="header-right">
        <div class="hr-box">
          <a href=""><img src="img/icons/cart.png" alt=""></a>
        </div>
      </li>
    </ul>
  </header>
  <div class="clearfix"></div>
  <!-- Header section end -->

<?php include 'connection.php';?>
  <div class="container">
    <div class="row">
      <div class="col-md-3"></div>
      <div class="col-md-6">
      <form method="post" enctype="multipart/form-data">
        <div class="form-group">
          <label for="fn">First Name:</label>
          <input type="text" class="form-control" id="fname" placeholder="Enter First Name" name="fname" required>
          <div class="invalid-feedback">Please fill out this field.</div>
        </div>
        <div class="form-group">
          <label for="ln">Last Name:</label>
          <input type="text" class="form-control" id="lname" placeholder="Enter Last Name" name="lname" required>
          <div class="invalid-feedback">Please fill out this field.</div>
        </div>
        <div class="form-group">
          <label for="dob">Date of Birth:</label>
          <input type="date" class="form-control" id="dob" placeholder="Select Date" name="dob" required>
          <div class="invalid-feedback">Please fill out this field.</div>
        </div>
        <div class="form-group">
          <label for="address">Address:</label>
          <textarea class="form-control" id="address" placeholder="Enter Address" rows="3" coloumn="50" name="address" required></textarea>
          <div class="invalid-feedback">Please fill out this field.</div>
        </div>
        <div class="form-group">
          <label for="Contact">Contact:</label>
          <input type="number" class="form-control" id="contact" placeholder="Enter Contact" name="contact" required>
          <div class="invalid-feedback">Please fill out this field.</div>
        </div>
        <div class="form-group">
          <label for="email">E-mail:</label>
          <input type="email" class="form-control" id="email" placeholder="Enter E-mail" name="email" required>
          <div class="invalid-feedback">Please fill out this field.</div>
        </div>
        <div class="form-group">
          <label for="password">Password:</label>
          <input type="password" class="form-control" id="password" placeholder="Enter Password" name="password" required>
          <div class="invalid-feedback">Please fill out this field.</div>
        </div>
        <div class="form-group">
          <label for="sec_ques">Security Questions:</label>
          <input type="text" class="form-control" id="sec_ques" placeholder="Enter Question" name="sec_ques" required>
          <div class="invalid-feedback">Please fill out this field.</div>
        </div>
        <div class="form-group">
          <label for="sec_ans">Security Answer:</label>
          <input type="text" class="form-control" id="sec_ans" placeholder="Enter Answer" name="sec_ans" required>
          <div class="invalid-feedback">Please fill out this field.</div>
        </div>
        <div class="form-group">
          <label for="Photo">Photo:</label>
          <input type="file" class="form-control" id="photo" placeholder="" name="photo" required>
          <div class="invalid-feedback">Please fill out this field.</div>
        </div>
        <?php
          //function upPhoto(){
            if(isset($_POST['submit'])){
              $pfile_name=$_FILES['photo']['name'];
              $pfile_temp_loc=$_FILES['photo']['tmp_name'];
              $pfile_store="./../../upload/".$pfile_name;
              if(move_uploaded_file($pfile_temp_loc, $pfile_store)){
                echo "uploaded";
              }
            }
          ?>
        <div class="form-group">
          <label for="doc">Document:</label>
          <input type="file" class="form-control" id="doc" placeholder="" name="doc" required>
          <div class="invalid-feedback">Please fill out this field.</div>
        </div>
        <?php
          //function upDoc(){
            if(isset($_POST['submit'])){
              $dfile_name=$_FILES['doc']['name'];
              $dfile_temp_loc=$_FILES['doc']['tmp_name'];
              $dfile_store="./../../upload/".$dfile_name;
              if(move_uploaded_file($dfile_temp_loc, $dfile_store)){
                echo "uploaded";
              }
            } 
          ?>
        <div class="form-group">
          <input type="submit" name="submit" value="Register">
        </div>
      </form>
      </div>
      <div class="col-md-3"></div>
    </div>
    <?php
    if(isset($_POST['submit'])){
      $f=$_POST["fname"];
      $l=$_POST["lname"];
      $d=$_POST["dob"];
      $a=$_POST["address"];
      $c=$_POST["contact"];
      $e=$_POST["email"];
      $p=$_POST["password"];
      $sq=$_POST["sec_ques"];
      $sa=$_POST["sec_ans"];
      $pf="upload/".$_FILES['photo']['name'];
      $df="upload/".$_FILES['doc']['name'];
      if($f!="" && $l!="" && $d!="" && $a!="" && $c!="" && $e!="" && $p!="" && $sq!="" && $sa!="" && $pf!="" && $df!=""){
      $query="INSERT INTO `user_master`(`f_name`, `l_name`, `dob`, `address`, `contact`, `email`, `password`, `sec_question`, `sec_answer`, `photo`, `document`, `certificate`, `company_company_id`, `user_type_type_id`) VALUES  
      ('$f','$l','$d','$a','$c','$e','$p','$sq','$sa','$pf','$df','',1,1)";
      if(mysqli_query($conn,$query)){
          echo "Records inserted successfully."; }
      else{
          echo "ERROR: Could not able to execute $query. " . mysqli_error($conn); } } }
      
          
  
    ?>
  </div>
  <p align="center">Already have an account?<a href="login.php">Login here.</a></p>
  <!-- Footer section -->
  <footer class="footer-section set-bg" data-setbg="img/footer-bg.jpg">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-sm-6">
          <div class="footer-widget">
            <h4>Location</h4>
            <div class="fw-info-box">
              <img src="img/icons/1.png" alt="">
              <div class="fw-info-text">
                <p> Ghodasar Cross Road, Near Cadila Bridge, Ahmedabad-380050</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="footer-widget">
            <h4>Contact</h4>
            <div class="fw-info-box">
              <img src="img/icons/2.png" alt="">
              <div class="fw-info-text">
                <p>+91 9727974099</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="footer-widget">
            <h4>E-mail</h4>
            <div class="fw-info-box">
              <img src="img/icons/3.png" alt="">
              <div class="fw-info-text">
                <p>unique@gmail.com</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6 order-2 order-md-1">
          <div class="copyright"><p>
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved.</p></div>
        </div>
        <div class="col-md-6 order-1 order-md-2">
          <ul class="footer-menu">
            <li><a href="index.php">Home</a></li>
            <li><a href="packages.php">Package</a></li>
            <li><a href="products.php">Product</a></li>
            <li><a href="contact.php">Contact us</a></li>
            <li><a href="about.php">About us</a></li> 
          </ul>
        </div>
      </div>
    </div>
  </footer>
  <!-- Footer section end -->
                        
  <!--====== Javascripts & Jquery ======-->
  <script src="js/jquery-3.2.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.slicknav.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/circle-progress.min.js"></script>
  <script src="js/main.js"></script>

  </body>
</html>

<!--      <table align="center" border=1 padding=50px>
        <tr>
          <td>First Name:</td><td><input type="text" name="fname"></td>
        </tr>
        <tr>
          <td>Last Name:</td><td><input type="text" name="lname"></td>
        </tr>
        <tr>
          <td>Date of Birth:</td><td><input type="date" name="dob"></td>
        </tr>
        <tr>
          <td>Address:</td><td><input type="text" name="address"></td>
        </tr>
        <tr>
          <td>Contact:</td><td><input type="number" name="contact"></td>
        </tr>
        <tr>
          <td>Email:</td><td><input type="text" name="email"></td>
        </tr>
        <tr>
          <td>password:</td><td><input type="password" name="password"></td>
        </tr>
        <tr>
          <td>Security Questions:</td><td><input type="text" name="sec_ques"></td>
        </tr>
        <tr>
          <td>Security Answer:</td><td><input type="text" name="sec_ans"></td>
        </tr>
        <tr>
          <td>
            photo:</td><td><input type="file" name="photo">
          </td>
          <td border:0px>
             </td>
        </tr>
        <tr>
          <td>
            Document:</td><td><input type="file" name="doc">
          </td>
          <td border:0px>
             </td>
        </tr>
        <tr>
          <td colspan=2 align="center"><input type="submit" name="submit" value="Register"></td>
        </tr>
      </table>-->