<?php
session_start();
//Checking User Logged or Not
if(empty($_SESSION['user'])){
 header('location:./../../index.php');
}
//Restrict User or Moderator to Access Admin.php page
if($_SESSION['user']['role']=='Customer'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Member'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Receptionist'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Admin'){
 header('location:./../../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">

	<link rel="stylesheet" type="text/css" href="./../assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/responsive.css">

	<script type="text/javascript" src="./../assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="./../assets/js/popper.min.js"></script>
	<script type="text/javascript" src="./../assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
</head>
<body>
	<?php include 'addons/header.php'; ?>
	<?php include 'addons/sidebar.php'; ?>
	<?php include 'addons/connection.php'; 
	?>
	<div class="contentCenterBody">
		<form method="post" enctype="multipart/form-data">
			<table>
				<tr>
          			<td> Select Member:</td>
          			<td>
            			<select name="member">
              			<?php $qry_m="SELECT * FROM `user_master` where user_type_type_id=2";
              				$res_m=mysqli_query($conn,$qry_m);
              				if (mysqli_num_rows($res_m)>0) {  
                				while ($row = mysqli_fetch_assoc($res_m)) { ?>
              					<option value="<?php echo $row['user_id']; ?>"><?php echo $row['f_name']." ".$row['l_name'];?></option>
              				<?php } }?>
            			</select>
          			</td>
        		</tr>
				<tr>
          			<td> Select Exercise:</td>
          			<td>
            			<select name="exercise">
              			<?php $qry_e="SELECT * FROM `exercise`";
              				$res_e=mysqli_query($conn,$qry_e);
              				if (mysqli_num_rows($res_e)>0) {  
                				while ($row = mysqli_fetch_assoc($res_e)) { ?>
              					<option value="<?php echo $row['exercise_id']; ?>"><?php echo $row['name'];?></option>
              				<?php } }?>
            			</select>
          			</td>
        		</tr>
				<tr>
					<td>Insert Day:</td><td><input type="text" name="days"></td><td>(can be week days or manual)</td>
				</tr>
				<tr>
					<td colspan=2 align="center"><input type="submit" name="submit" value="SUBMIT"></td>
				</tr>
			</table>
		</form>
		<?php
		if(isset($_POST['submit'])){
			$m=$_POST["member"];
			$e=$_POST["exercise"];
			$d=$_POST["days"];
			if($m!="" && $e!="" && $d!=""){
			$query="INSERT INTO `user_master_has_exercise`(`user_master_user_id`, `exercise_exercise_id`, `day`) VALUES ('$m', '$e', '$d')";
			if(mysqli_query($conn,$query)){
    			echo "Records inserted successfully.<br />";
    			echo "<a href='exercise.php'>back</a>"; }
			else{
    			echo "ERROR: Could not able to execute $query. " . mysqli_error($conn); } } }
    	
    			
	
		?>
	</div>
	<?php include 'addons/footer.php'; ?>
</body>
</html>