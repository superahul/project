<div class="sideMenu">
	<div class="userDisplayCard">
		<p class="">Trainer</p>
	</div>
	<div class="SideNavMenu">
		<ul>
			<li class="menu1 hasSideMenu">
				<a href="#"><i class="fa fa-home"></i> Customer <i class="fa fa-angle-right right_drop"></i></a>
				<ul class="nav_sideMenu">
					<li class="menu20"><a href="give_exercise.php"> Give Exercise </a></li>
					<li class="menu21"><a href="#"> Give Diet </a></li>
				</ul>
			</li>
			<li class="hasSideMenu">
				<a href="measurement.php"><i class="fa fa-home"></i> Measurement </a>
			</li>
			<li class="hasSideMenu">
				<a href="#"><i class="fa fa-home"></i> Exercise <i class="fa fa-angle-right right_drop"></i></a>
				<ul class="nav_sideMenu">
					<li class="menu20"><a href="exercise_type.php"> Exercise Type </a></li>
					<li class="menu21"><a href="exercise.php"> Exercise </a></li>
				</ul>
			</li>
			<li class="hasSideMenu">
				<a href="#"><i class="fa fa-home"></i> Diet Plan <i class="fa fa-angle-right right_drop"></i></a>
				<ul class="nav_sideMenu">
					<li class="menu20"><a href="diet_type.php"> Diet Type </a></li>
					<li class="menu21"><a href="diet.php"> Diet </a></li>
				</ul>
			</li>			
		</ul>
	</div>
</div>