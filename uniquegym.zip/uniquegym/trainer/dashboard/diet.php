<?php
session_start();
//Checking User Logged or Not
if(empty($_SESSION['user'])){
 header('location:./../../index.php');
}
//Restrict User or Moderator to Access Admin.php page
if($_SESSION['user']['role']=='Customer'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Member'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Receptionist'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Admin'){
 header('location:./../../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">

	<link rel="stylesheet" type="text/css" href="./../assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/responsive.css">

	<script type="text/javascript" src="./../assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="./../assets/js/popper.min.js"></script>
	<script type="text/javascript" src="./../assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
</head>
<body>
	<?php include 'addons/header.php'; ?>
	<?php include 'addons/sidebar.php'; ?>
	<?php include 'addons/connection.php'; 
	?>
	<div class="contentCenterBody">
		<h5 align="center">Diet</h5>
		<a href="add_diet.php">Add Diet</a>
		<table>
			<tr align="center">
				<th width="20%"></th>
				<th width="20%"></th>
				<th width="20%">Type</th>
				<th width="60%">Description</th>
			</tr>
		<?php
		$qry="select * from diet_plan as d inner join diet_type as t on t.diet_type_id=d.diet_type_diet_type_id";
		$res=mysqli_query($conn,$qry);
		if (mysqli_num_rows($res)>0) {  
				while ($row = mysqli_fetch_assoc($res)) {	?>
				
					<tr align="center">
						<td><a href="update_diet.php?eid=<?php echo $row['diet_id'];?>">Update</a></td>
						<td><a href="delete_diet.php?did=<?php echo $row['diet_id'];?>">Delete</a></td>
						<td><?php echo $row["diet_type"]; ?></td>
						<td><?php echo $row["description"]; ?></td>
					</tr><?php } } ?>
		</table>
	</div>
	<?php include 'addons/footer.php'; ?>
</body>
</html>