<?php
session_start();
//Checking User Logged or Not
if(empty($_SESSION['user'])){
 header('location:./../../index.php');
}
//Restrict User or Moderator to Access Admin.php page
if($_SESSION['user']['role']=='Customer'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Member'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Receptionist'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Admin'){
 header('location:./../../index.php');
}
?>
<?php include 'addons/connection.php'; 
  ?>
<?php
    if(isset($_POST['submit'])){
      $cid=$_POST["cid"];
      $height=$_POST["height"];
      $weight=$_POST["weight"];
   
      if($cid!="" && $height!="" && $weight!=""){
      $query="INSERT INTO `measurement`(`weight`, `height`, `user_master_user_id`) VALUES ('$weight','$height','$cid')";
      if(mysqli_query($conn,$query)){
          echo "Records inserted successfully."; }
      else{
          echo "ERROR: Could not able to execute $query. " . mysqli_error($conn); } } }
      
          
  
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">

	<link rel="stylesheet" type="text/css" href="./../assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/responsive.css">

	<script type="text/javascript" src="./../assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="./../assets/js/popper.min.js"></script>
	<script type="text/javascript" src="./../assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
</head>
<body>
	<?php include 'addons/header.php'; ?>
	<?php include 'addons/sidebar.php'; ?>
	
	<div class="contentCenterBody">
		<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
      <table>
        <tr>
          <td>Member Name:</td>
          <td><select name="cid">
              <?php $qry="SELECT * FROM `user_master` WHERE user_type_type_id=2";
              	  	$res=mysqli_query($conn,$qry);
              		if (mysqli_num_rows($res)>0) {  
              			while ($row = mysqli_fetch_assoc($res)) { ?>
              				<option value="<?php echo $row['user_id']; ?>"><?php echo $row['f_name'] . " " . $row['l_name'];?></option>
              					<?php } }?>
            	</select>
           </td>
        </tr>
        <tr>
          <td>Height:</td><td><input type="text" name="height"></td>
        </tr>
        <tr>
          <td>Weight:</td><td><input type="text" name="weight"></td>
        </tr>
        <tr>
          <td colspan=2 align="center"><input type="submit" name="submit" value="ADD"></td>
        </tr>
      </table>
    </form>		
	</div>
	<?php include 'addons/footer.php'; ?>
</body>
</html>