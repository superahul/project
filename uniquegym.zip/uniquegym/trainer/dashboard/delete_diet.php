<?php include 'addons/connection.php'; 
	$del=$_GET['did'];
	if($del!=""){
		$query="DELETE FROM `diet_plan` WHERE diet_id='$del'";
		mysqli_query($conn,$query); }
    	header("location:diet.php")		
	?>