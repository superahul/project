<?php include 'addons/connection.php'; 
	$del=$_GET['did'];
	if($del!=""){
		$query="DELETE FROM `exercise` WHERE exercise_id='$del'";
		mysqli_query($conn,$query); }
    	header("location:exercise.php")		
	?>