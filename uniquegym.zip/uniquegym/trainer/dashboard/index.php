<?php
session_start();
//Checking User Logged or Not
if(empty($_SESSION['user'])){
 header('location:./../../index.php');
}
//Restrict User or Moderator to Access Admin.php page
if($_SESSION['user']['role']=='Customer'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Member'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Receptionist'){
 header('location:./../../index.php');
}
if($_SESSION['user']['role']=='Admin'){
 header('location:./../../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Dashboard</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">

	<link rel="stylesheet" type="text/css" href="./../assets/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="./../assets/css/responsive.css">

	<script type="text/javascript" src="./../assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="./../assets/js/popper.min.js"></script>
	<script type="text/javascript" src="./../assets/js/bootstrap.min.js"></script>

	
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
</head>
<body>
	<?php include 'addons/header.php'; ?>
	<?php include 'addons/sidebar.php'; ?>
	
	<?php include 'addons/grid_widgets.php'; ?>

	<div class="contentCenterBody">
		<div class="panel_body">
			<h3 class="headingTitle">Single Line Details</h3>
			<table class="tableUi stripe" id="myTable">
				<thead>
					<tr>
						<th>Pool</th>
						<th>Direct Sales</th>
						<th>Completed On</th>
						<th>Required Level</th>
						<th>Level Completed</th>
						<th>Level Completed On</th>
						<th>Qualified Status</th>
						<th>Incentive Status</th>
					</tr>
				</thead>
				<tbody>
					<tr>
					 	<td>Alfreds</td>
					    <td>Maria Anders</td>
					    <td>Germany</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					    <td>Germany</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					</tr>
					<tr>
					    <td>Centro</td>
					    <td>Francisco Chang</td>
					    <td>Mexico</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					    <td>Germany</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					</tr>
					<tr>
					    <td>Ernst Handel</td>
					    <td>Roland Mendel</td>
					    <td>Austria</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					    <td>Germany</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					</tr>
					<tr>
					    <td>Island Trading</td>
					    <td>Helen Bennett</td>
					    <td>UK</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					    <td>Germany</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					</tr>
					<tr>
					    <td>Laughing </td>
					    <td>Yoshi Tannamuri</td>
					    <td>Canada</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					    <td>Germany</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					</tr>
					<tr>
					    <td>Magazzini</td>
					    <td>Giovanni Rovelli</td>
					    <td>Italy</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					    <td>Germany</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					</tr>
					<tr>
					 	<td>Alfreds</td>
					    <td>Maria Anders</td>
					    <td>Germany</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					    <td>Germany</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					</tr>
					<tr>
					    <td>Centro</td>
					    <td>Francisco Chang</td>
					    <td>Mexico</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					    <td>Germany</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					</tr>
					<tr>
					    <td>Ernst Handel</td>
					    <td>Roland Mendel</td>
					    <td>Austria</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					    <td>Germany</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					</tr>
					<tr>
					    <td>Island Trading</td>
					    <td>Helen Bennett</td>
					    <td>UK</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					    <td>Germany</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					</tr>
					<tr>
					    <td>Laughing </td>
					    <td>Yoshi Tannamuri</td>
					    <td>Canada</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					    <td>Germany</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					</tr>
					<tr>
					    <td>Magazzini</td>
					    <td>Giovanni Rovelli</td>
					    <td>Italy</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					    <td>Germany</td>
					    <td>Alfreds</td>
					    <td>Maria Anders</td>
					</tr>
				</tbody>
			</table>

			<button class="call_Success">Success</button>
			<button class="call_Danger">Danger</button>
			<button class="call_Warning">Warning</button>
		</div>
	</div>
	



	<?php include 'addons/footer.php'; ?>



	<script type="text/javascript">
		$('#myTable').DataTable({
			"scrollX": true
		});
	</script>
</body>
</html>